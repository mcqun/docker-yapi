## 怎么分享我的插件？
Fork [yapi](https://github.com/YMFE/yapi), 然后修改 docs/documents/plugin-list.md, 修改完成后请 Pull-Request.

## 插件列表

* [qsso](https://github.com/ymfe/yapi-plugin-qsso) sso 第三方登录
